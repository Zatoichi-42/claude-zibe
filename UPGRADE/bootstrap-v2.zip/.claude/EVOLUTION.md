# Bootstrap Evolution Log

## Instruction Budget
CLAUDE.md rule count: 6 | Budget (<25): 19 remaining

## Proposed Rules (Awaiting Human Review)
<!-- /retro writes proposals here. Human promotes or rejects. -->

## Session Scores
<!-- /retro appends session quality scores here. -->

## Promoted Rules
<!-- Accepted rules move here with the date promoted. -->

## Rejected Rules (With Reason)
<!-- Rejected rules move here with explanation why. -->

## Retired Rules
<!-- Rules removed because they weren't preventing failures. -->
