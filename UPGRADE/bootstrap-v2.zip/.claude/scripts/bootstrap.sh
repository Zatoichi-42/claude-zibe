#!/usr/bin/env bash
set -euo pipefail

# ============================================================================
# Bootstrap — One-Command Setup
# Usage: bash .claude/scripts/bootstrap.sh
# Idempotent — safe to run multiple times.
# ============================================================================

echo "🚀 Bootstrap — Initializing..."

G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "  ${G}✓${NC} $1"; }
warn() { echo -e "  ${Y}⚠${NC} $1"; }
fail() { echo -e "  ${R}✗${NC} $1"; }

# --- Directories ---
echo "📁 Directories..."
for d in .claude/{agents,commands,hooks,skills,logs,reports,rules,docs,scripts}; do
  mkdir -p "$d" && ok "$d/"
done

# --- Hook permissions ---
echo "🔒 Hook permissions..."
if ls .claude/hooks/*.sh 1>/dev/null 2>&1; then
  chmod +x .claude/hooks/*.sh
  for h in .claude/hooks/*.sh; do ok "$(basename "$h")"; done
else
  warn "No hooks found in .claude/hooks/"
fi

# --- Critical files ---
echo "📋 Critical files..."
ALL_OK=true
for f in CLAUDE.md .claude/settings.json TODO.md program.md; do
  if [ -f "$f" ]; then ok "$f"; else fail "$f — MISSING"; ALL_OK=false; fi
done

# --- Git ---
echo "🔀 Git..."
if [ -d ".git" ]; then
  ok "Git initialized ($(git branch --show-current 2>/dev/null || echo 'detached'))"
else
  git init && ok "Git initialized"
fi

# --- .gitignore ---
echo "📝 .gitignore..."
[ ! -f ".gitignore" ] && touch .gitignore
for entry in ".env" ".env.*" "*.key" "*.pem" ".claude/logs/" ".claude/JOURNAL.md" ".claude/HANDOFF.md" ".claude/.tdd-red-phase" "node_modules/" "__pycache__/" "*.pyc" ".pytest_cache/"; do
  grep -qF "$entry" .gitignore 2>/dev/null || { echo "$entry" >> .gitignore; ok "$entry added"; }
done

# --- Tools ---
echo "🔧 Tools..."
command -v python3 >/dev/null 2>&1 && ok "python3 $(python3 --version 2>&1 | cut -d' ' -f2)" || warn "python3 not found"
command -v jq >/dev/null 2>&1 && ok "jq $(jq --version 2>&1)" || fail "jq not found — REQUIRED for hooks"
command -v git >/dev/null 2>&1 && ok "git $(git --version | cut -d' ' -f3)" || fail "git not found"

# --- Baseline measurement ---
echo "📊 Measuring baseline..."
TESTS_PASS=0; TESTS_FAIL=0; LINT_ERRORS=0
if [ -f "pyproject.toml" ] || [ -f "pytest.ini" ] || [ -f "setup.py" ] || [ -f "setup.cfg" ]; then
  TEST_OUT=$(python -m pytest --tb=no -q 2>&1 || true)
  TESTS_PASS=$(echo "$TEST_OUT" | grep -oP '\d+ passed' | grep -oP '\d+' || echo 0)
  TESTS_FAIL=$(echo "$TEST_OUT" | grep -oP '\d+ failed' | grep -oP '\d+' || echo 0)
  ok "Tests: $TESTS_PASS passing, $TESTS_FAIL failing"
elif [ -f "package.json" ] && grep -q '"test"' package.json 2>/dev/null; then
  TEST_OUT=$(npm run test -- --passWithNoTests 2>&1 || true)
  ok "Tests: ran (check output)"
else
  warn "No test runner detected"
fi

if command -v ruff >/dev/null 2>&1; then
  LINT_ERRORS=$(ruff check . 2>/dev/null | wc -l | tr -d ' ' || echo 0)
  ok "Lint: $LINT_ERRORS issues"
fi

# Write baseline to ratchet-state
if command -v jq >/dev/null 2>&1; then
  NOW=$(date -Iseconds)
  cat > .claude/ratchet-state.json << JSON
{
  "version": "1.0",
  "created": "$NOW",
  "last_updated": "$NOW",
  "best_score": null,
  "experiment_count": 0,
  "consecutive_failures": 0,
  "baseline_metrics": {
    "tests_passing": $TESTS_PASS,
    "tests_failing": $TESTS_FAIL,
    "lint_errors": $LINT_ERRORS,
    "timestamp": "$NOW"
  },
  "experiments": [],
  "kept_improvements": [],
  "exhausted_directions": [],
  "notes": "Baseline measured by bootstrap."
}
JSON
  ok "Ratchet baseline written"
fi

# --- Summary ---
echo ""
echo "============================================"
if [ "$ALL_OK" = true ]; then
  echo -e "${G}✓ Bootstrap complete!${NC}"
  echo "  Next: run /health, then /plan or /implement"
else
  echo -e "${Y}⚠ Partially complete — create missing files${NC}"
fi
echo "============================================"
