#!/usr/bin/env bash
set -euo pipefail

# ============================================================================
# CONDUCTOR — External Claude Code Session Controller
# Runs OUTSIDE Claude Code. Restarts work through crashes and rate limits.
#
# Usage:
#   bash .claude/scripts/conductor.sh --auto --budget 5
#   bash .claude/scripts/conductor.sh --check
# ============================================================================

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
STATE_FILE="$PROJECT_DIR/.claude/conductor-state.json"
LOG_FILE="$PROJECT_DIR/.claude/logs/conductor.log"
PIDFILE="$PROJECT_DIR/.claude/conductor.pid"

MAX_BUDGET="${CONDUCTOR_BUDGET:-10}"
MAX_CONSECUTIVE_FAILS=3
MAX_SESSIONS=30
RATE_LIMIT_WAIT=300
SESSION_TIMEOUT=600
MAX_TURNS=25

log() { echo "[$(date +%H:%M:%S)] $1" | tee -a "$LOG_FILE" 2>/dev/null; }

init_state() {
  mkdir -p "$(dirname "$STATE_FILE")" "$(dirname "$LOG_FILE")"
  [ -f "$STATE_FILE" ] || cat > "$STATE_FILE" << 'JSON'
{"status":"idle","total_sessions":0,"total_cost_usd":0,"consecutive_failures":0,"last_exit_reason":null,"history":[]}
JSON
}

read_state() { jq -r "$1" "$STATE_FILE" 2>/dev/null || echo "0"; }

update_state() {
  local tmp=$(mktemp)
  jq "$1" "$STATE_FILE" > "$tmp" 2>/dev/null && mv "$tmp" "$STATE_FILE"
}

get_next_task() {
  local task=""
  for f in "$PROJECT_DIR/TODO.md" "$PROJECT_DIR/.claude/TODO.md"; do
    [ -f "$f" ] && { task=$(grep -m1 '^\- \[ \]' "$f" 2>/dev/null | sed 's/^- \[ \] //' || true); break; }
  done
  [ -z "$task" ] && task="Run /ratchet following program.md directions."
  echo "$task"
}

build_prompt() {
  local task="$1"
  local ctx=""
  [ -f "$PROJECT_DIR/.claude/JOURNAL.md" ] && ctx="Previous session state:\n$(cat "$PROJECT_DIR/.claude/JOURNAL.md")\n\n"
  printf '%b' "${ctx}Read CLAUDE.md first.\n\nTASK: ${task}\n\nRules: Follow TDD. Commit after each item. If stuck 3x, log to BLOCKED.md and skip. Write JOURNAL.md when done.\n\nBEGIN."
}

run_session() {
  local task="$1"
  local prompt=$(build_prompt "$task")
  local start=$(date +%s)
  local result_file=$(mktemp)
  local exit_code=0

  log "━━━ Session #$(($(read_state '.total_sessions') + 1)): ${task:0:80}..."
  update_state '.status = "running"'

  timeout "$SESSION_TIMEOUT" claude -p "$prompt" \
    --output-format json \
    --max-turns "$MAX_TURNS" \
    --permission-mode auto \
    --allowedTools "Read,Write,Edit,MultiEdit,Bash,Glob,Grep,Agent" \
    > "$result_file" 2>>"$LOG_FILE" || exit_code=$?

  local duration=$(( $(date +%s) - start ))
  local cost=$(jq -r '.total_cost_usd // 0' "$result_file" 2>/dev/null || echo "0")
  local is_error=$(jq -r '.is_error // false' "$result_file" 2>/dev/null || echo "false")
  local result_text=$(jq -r '.result // ""' "$result_file" 2>/dev/null | head -c 500)

  local reason="completed"
  if [ "$exit_code" -eq 124 ]; then reason="timeout"
  elif [ "$is_error" = "true" ]; then
    echo "$result_text" | grep -qi "rate.limit\|429" && reason="rate_limit" || reason="error"
  fi

  local fails=$(read_state '.consecutive_failures')
  [ "$reason" = "completed" ] && fails=0 || fails=$((fails + 1))

  update_state "
    .total_sessions += 1 |
    .total_cost_usd += $cost |
    .consecutive_failures = $fails |
    .last_exit_reason = \"$reason\" |
    .history += [{\"task\":\"$(echo "$task" | head -c 80 | sed 's/"/\\"/g')\",\"reason\":\"$reason\",\"duration\":$duration,\"cost\":$cost,\"time\":\"$(date -Iseconds)\"}]
  "

  log "Session ended: $reason (${duration}s, \$$cost)"
  rm -f "$result_file"
  echo "$reason"
}

auto_loop() {
  # Pidfile lock
  if [ -f "$PIDFILE" ]; then
    local old=$(cat "$PIDFILE" 2>/dev/null)
    kill -0 "$old" 2>/dev/null && { log "Another conductor running (PID $old)"; exit 1; }
    rm -f "$PIDFILE"
  fi
  echo $$ > "$PIDFILE"
  trap 'rm -f "$PIDFILE"' EXIT INT TERM

  log "━━━ CONDUCTOR AUTO MODE (budget: \$$MAX_BUDGET) ━━━"
  update_state '.status = "auto"'
  local rate_fails=0

  while true; do
    local cost=$(read_state '.total_cost_usd')
    local fails=$(read_state '.consecutive_failures')

    (( $(echo "$cost >= $MAX_BUDGET" | bc -l 2>/dev/null || echo 0) )) && { log "STOP: Budget reached"; break; }
    [ "$fails" -ge "$MAX_CONSECUTIVE_FAILS" ] && { log "STOP: $fails consecutive failures"; break; }

    local task=$(get_next_task)
    [ -z "$task" ] && { log "STOP: No tasks"; break; }

    local reason=$(run_session "$task")
    case "$reason" in
      completed) rate_fails=0; sleep 5 ;;
      rate_limit)
        rate_fails=$((rate_fails + 1))
        [ "$rate_fails" -ge 3 ] && { log "STOP: 3 rate limits"; break; }
        local wait=$((RATE_LIMIT_WAIT * (2 ** (rate_fails - 1))))
        log "Rate limited. Waiting ${wait}s..."
        sleep "$wait" ;;
      timeout) sleep 10 ;;
      error) sleep 30 ;;
    esac
  done

  update_state '.status = "idle"'
  log "━━━ DONE: $(read_state '.total_sessions') sessions, \$$(read_state '.total_cost_usd') spent ━━━"
}

status_check() {
  echo "━━━ CONDUCTOR ━━━"
  echo "Sessions: $(read_state '.total_sessions')"
  echo "Cost:     \$$(read_state '.total_cost_usd') / \$$MAX_BUDGET"
  echo "Failures: $(read_state '.consecutive_failures') / $MAX_CONSECUTIVE_FAILS"
  echo "Last:     $(read_state '.last_exit_reason')"
  echo "━━━━━━━━━━━━━━━━━"
}

cd "$PROJECT_DIR"
init_state

case "${1:-}" in
  --auto) auto_loop ;;
  --check) status_check ;;
  --reset) rm -f "$STATE_FILE"; init_state; log "State reset." ;;
  *) echo "Usage: conductor.sh --auto [--budget N] | --check | --reset"; status_check ;;
esac
