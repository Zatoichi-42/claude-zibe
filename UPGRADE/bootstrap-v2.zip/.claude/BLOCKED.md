# Blocked Items
<!-- Items that are stuck. Format: [date] [item] — [reason] -->
<!-- Clear entries after they're resolved. -->
