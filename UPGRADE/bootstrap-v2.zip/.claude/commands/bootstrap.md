# /bootstrap — Initialize and Measure Baseline

## Steps
1. Verify directory structure exists (.claude/agents, commands, hooks, skills, logs, reports, rules)
2. Create missing directories
3. Make all hooks executable: `chmod +x .claude/hooks/*.sh`
4. Verify git is initialized
5. Run health checks (tests, lint, build)
6. **Initialize ratchet baseline** — measure and write to .claude/ratchet-state.json
7. Report status

This command is idempotent — safe to run multiple times.
