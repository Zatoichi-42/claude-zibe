---
name: health
---
# /health — Project Health Check

Run all checks and report:
1. Git: clean? branch? uncommitted changes?
2. Tests: all passing? count? time?
3. Lint: errors? warnings?
4. Build: succeeds? warnings?
5. Ratchet: current baseline from .claude/ratchet-state.json
6. TODO: remaining vs completed
7. Blocked: items in .claude/BLOCKED.md

Output a concise dashboard to stdout. Flag anything needing attention.
