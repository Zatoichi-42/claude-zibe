---
name: digest
---
# /digest — Daily Summary

Write to `.claude/reports/digest-[YYYY-MM-DD].md` AND print to stdout.

## Format
```markdown
# Digest — [DATE]
## 🚦 Health: [GREEN/YELLOW/RED]
[One sentence why]

## Tests: NN pass / NN fail | Time: NNs
## Lint: NN errors, NN warnings
## Git: NN commits today, branch: [name]

## TODO Progress
  Done: NN | Remaining: NN | Blocked: NN
  Next 3:
    1. [task]
    2. [task]
    3. [task]

## Ratchet: NN experiments, NN kept, score: NN

## ⚠ Warnings
  [Anything needing human attention]

## What Happened Today
  [3-5 sentence summary from git log]
```

Keep under 40 lines. Readable via `cat`. No server needed.
