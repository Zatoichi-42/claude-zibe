---
name: ratchet
argument-hint: "[specific area or empty for program.md]"
---
# /ratchet — Autonomous Improvement Loop

## Process
1. Load ratchet-loop skill
2. Read program.md for directions
3. Load or establish baseline from .claude/ratchet-state.json
4. Run the six-step loop (max 10 experiments per session)
5. Report results

## Safety
- Reverts ALL changes that don't improve metrics
- Never modifies test files
- Commits each improvement individually
- Stops at 50% context
