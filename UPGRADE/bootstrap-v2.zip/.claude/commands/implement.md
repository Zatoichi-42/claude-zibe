---
name: implement
argument-hint: "[feature or TODO item]"
---
# /implement — Build with TDD

## Process
1. Load tdd-loop skill
2. If $ARGUMENTS is vague, ask: input? output? error behavior?
3. Create .claude/.tdd-red-phase marker
4. RED: Write failing tests (try subagent first, fallback to direct)
5. Remove .claude/.tdd-red-phase marker
6. GREEN: Implement minimal code (try subagent first, fallback to direct)
7. REFACTOR: Clean up while green
8. VERIFY: Full test suite + lint
9. COMMIT: `git add -A && git commit -m "feat: [description]"`
10. Update TODO.md: mark the item complete

## If Blocked
If any step fails after 3 attempts:
1. Log to .claude/BLOCKED.md: `[date] [item] — [reason]`
2. Commit what you have
3. Move to next TODO item
4. Do NOT stall the session
