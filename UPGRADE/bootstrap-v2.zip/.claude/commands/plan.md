---
name: plan
argument-hint: "[feature or problem description]"
---
# /plan — Think Before You Build

Load the self-plan skill. Run the full protocol on: $ARGUMENTS

Output: .claude/PLAN.md + provable TODO items appended to TODO.md

If task is large (>5 files), delegate critique to self-critic agent.
