---
name: prove
argument-hint: "[optional: specific TODO item text to prove]"
---
# /prove — Verify TODO Items Are Actually Done

## Process
1. Read TODO.md
2. Find all unchecked items (`- [ ]`) that have `proof-command:` metadata
3. For each (or for the specific item if $ARGUMENTS given):
   a. Run the proof-command
   b. If exit code 0: mark `- [ ]` → `- [x]` directly in TODO.md
   c. If exit code non-zero: leave unchecked, print failure reason
4. Commit the updated TODO.md if any items were checked off

## One-Step Completion
This replaces the old 3-command ceremony (prove → sync → commit).
/prove does all three: runs proof, updates TODO, commits.

## Example
```
$ /prove
Proving: Forward returns computed for 1D, 5D, 10D, 20D
  → python -m pytest tests/test_forward_returns.py -v
  → PASS ✓ (marked complete)

Proving: Hit rate by setup type populated
  → python -c "import json; d=json.load(...)..."
  → FAIL ✗ (KeyError: 'hit_rate_by_setup')

Results: 1 proven, 1 failed, 3 without proof-commands
```
