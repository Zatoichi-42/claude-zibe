---
name: retro
---
# /retro — Session Retrospective

Load meta-ratchet skill. Analyze this session:
1. Read JOURNAL.md and recent git history
2. Identify failures from checklist
3. Formulate candidate rules
4. Write proposals to .claude/EVOLUTION.md
5. Score the session
6. Print summary to stdout

IMPORTANT: /retro PROPOSES changes. It does NOT modify CLAUDE.md directly.
Human reviews EVOLUTION.md and decides what gets promoted.
