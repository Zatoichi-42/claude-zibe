---
name: check
---
# /check — 30-Second Spot Check

Print to stdout ONLY. No files. Under 25 lines. Under 10 seconds.

```
━━━ SPOT CHECK [datetime] ━━━━━━━━━━━━━━━━━━━━━
🚦 [GREEN/YELLOW/RED] [one-sentence reason]

SINCE LAST CHECK:
  Commits: N    Files changed: N
  Tests: N pass / N fail
  Ratchet: N experiments, N kept

LAST 3 COMMITS:
  • [hash] [message]

CONCERNS:
  [list or "None — looking good"]

NEXT TASK:
  [first incomplete TODO item]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Gather data FAST:
- `git log --oneline --since="24 hours ago" | head -5`
- `python -m pytest --tb=no -q 2>&1 | tail -3`
- `grep -m1 '^\- \[ \]' TODO.md`

NEVER generate files. NEVER run full test suite.
