---
paths:
  - "**/*.sh"
  - "**/*.env*"
  - "**/hooks/**"
  - "**/settings.json"
  - "**/Dockerfile"
---

# Safety Rules

## Absolute
1. NEVER hardcode secrets, API keys, passwords in any file
2. NEVER commit .env files (verify .gitignore)
3. NEVER use `eval` on user input in shell scripts
4. NEVER chmod 777

## Shell Scripts
- Start with `#!/usr/bin/env bash`
- Quote all variables: `"$VAR"` not `$VAR`
- Use `[[ ]]` not `[ ]` for conditionals
- Handle errors explicitly

## Hooks
- exit 0 = allow, exit 2 = block (exit 1 is NON-BLOCKING!)
- JSON output: `{"hookSpecificOutput":{"decision":"block","reason":"..."}}`
- Keep hooks FAST (< 5 seconds)
- Always check for jq before parsing JSON
- Always `trap '... exit 2' ERR` for fail-closed behavior
