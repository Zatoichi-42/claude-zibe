---
paths:
  - "**/*.test.*"
  - "**/*.spec.*"
  - "**/test_*"
  - "**/*_test.py"
  - "**/__tests__/**"
  - "**/tests/**"
---

# Testing Rules

## Structure
- One test file per source file, mirroring src/ structure
- Group related tests with describe/class blocks
- Descriptive names: `test_returns_404_when_user_not_found`

## Principles
- Tests are SPECIFICATIONS, not implementation details
- Test behavior, not implementation
- One assertion per test (focused tests)
- Each test independent — no shared mutable state
- Mock external dependencies, NEVER mock the unit under test

## Bug Fix Protocol
- Exact error string from user → reproduce in a test
- Reproduce the user's exact command before claiming "fixed"
- For CLI bugs: test the real entrypoint, not just internal functions

## When Writing New Tests
- Run BEFORE implementation — confirm it FAILS (RED)
- Passing test on first run = testing the wrong thing
- After implementation: confirm it PASSES (GREEN)

## When Tests Fail
- Fix the IMPLEMENTATION, not the test
- If test genuinely has a bug, ask the user
- Never delete a failing test to make the suite pass
