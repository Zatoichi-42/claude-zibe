---
name: ratchet-loop
description: >
  Autonomous improvement loop. Propose-implement-measure-keep/revert cycles.
  Use for "improve", "optimize", "ratchet", "make it better", or "/ratchet".
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
  - Glob
  - Grep
---

# Ratchet Loop — Autonomous Improvement

## The Six Steps

### 1. BASELINE
Load .claude/ratchet-state.json. If empty/missing, measure everything now:
- Test suite: pass count, fail count, time
- Build: success/fail, warnings
- Lint: error count, warning count
- Save to ratchet-state.json

### 2. HYPOTHESIZE
Read program.md for directions. Propose ONE atomic change:
- What changes
- Why it should improve things
- What metric proves it
- Rollback plan (usually `git checkout -- <files>`)

ONE change per cycle. Multiple changes = can't attribute results.

### 3. IMPLEMENT
Note current HEAD. Make the minimal change.

### 4. MEASURE
Run same measurements as step 1. Compare every metric.

Score formula:
```
score = (tests_passing / total) * 40
      + (build_success ? 20 : 0)
      + max(0, (1 - lint_errors / max(baseline_lint, 1))) * 15
      + (custom_improvement) * 25
```

### 5. DECIDE
- Score >= baseline AND no new test failures → **KEEP**
  - `git add -A && git commit -m "ratchet: [description]"`
  - Update ratchet-state.json
- Score < baseline OR new failures → **REVERT**
  - `git checkout -- .`
  - Log failure

The ratchet only turns one way. Never lower the bar.

### 6. LEARN & ITERATE
- Log result to ratchet-state.json experiments array
- 3+ consecutive failures on same area → skip it, try different direction
- GOTO step 2

## Session Budget
- Maximum 10 experiments per session (not 20 — leaves context for reporting)
- At 50% context: stop loop, commit, write JOURNAL.md
- At end: report summary of kept/reverted experiments

## Stopping Conditions
- User interrupts
- All program.md directions explored
- 5 consecutive experiments with no improvement
- Context approaching 50%
- Critical failure (tests go from passing to crashing)

## On Stop: Report
Print summary:
- Total experiments
- Improvements kept (with descriptions)
- Failed experiments (with reasons)
- Current vs original metrics
- Suggestions for next session
