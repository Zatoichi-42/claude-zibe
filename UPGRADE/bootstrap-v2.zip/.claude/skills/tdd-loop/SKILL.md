---
name: tdd-loop
description: >
  Red-Green-Refactor TDD cycle with subagent isolation and FALLBACK.
  Use when implementing features: "implement", "build", "add feature", "TDD".
  Does NOT trigger for bug fixes, docs, or config changes.
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
  - Glob
  - Grep
  - Agent
---

# TDD Loop — Red/Green/Refactor with Fallback

## Why Subagents
Subagents have separate context windows. This prevents "cheating" where
the LLM writes tests that match its planned implementation.

## CRITICAL: Write-Guard Compatibility
Before delegating RED phase to a subagent:
1. Create marker file: `touch .claude/.tdd-red-phase`
After RED phase completes:
2. Remove marker: `rm -f .claude/.tdd-red-phase`
This marker tells the pre-write-guard hook to allow test file writes.

## Workflow

### Phase 1: PLAN (Main Agent)
1. Understand the feature requirement
2. Name the tests first — plain language list of behaviors
3. For each behavior: input, expected output, edge cases

### Phase 2: RED — Write Failing Tests
Create the marker file first:
```bash
touch .claude/.tdd-red-phase
```

Then delegate to tdd-test-writer subagent:
```
Agent(
  agent_type="tdd-test-writer",
  prompt="Write failing tests for: [feature]. Behaviors: [list]. Test file: [path].",
)
```

After subagent returns:
1. Remove marker: `rm -f .claude/.tdd-red-phase`
2. Run tests — they MUST fail (red)
3. If tests pass → tests are wrong
4. If subagent returns empty or errors → **FALLBACK** (see below)
5. Commit tests: `git add && git commit -m "test: red — [feature]"`

### Phase 3: GREEN — Minimal Implementation
Delegate to tdd-implementer subagent:
```
Agent(
  agent_type="tdd-implementer",
  prompt="Make these tests pass with MINIMAL code: [test file]. Do not modify tests.",
)
```

After subagent returns:
1. Run tests — must PASS (green)
2. If still failing → try one more iteration with error output
3. If still failing after 2 attempts → **FALLBACK**
4. Commit: `git add && git commit -m "feat: green — [feature]"`

### Phase 4: REFACTOR
Review the implementation yourself (main context):
1. Look for duplication, clarity, naming
2. Refactor one thing at a time — test after each
3. If tests break → revert that change
4. Commit: `git add && git commit -m "refactor: [what]"`

### Phase 5: VERIFY
1. Run FULL test suite (not just new tests)
2. Run linter
3. If anything new fails → fix or revert

## FALLBACK PROCEDURE
When a subagent stalls, returns empty, or errors after 2 attempts:

1. Log: "Subagent [name] failed on [task]. Falling back to direct implementation."
2. Remove the TDD marker: `rm -f .claude/.tdd-red-phase`
3. Write tests directly in main context (no subagent)
4. Continue with GREEN phase in main context
5. Note in JOURNAL.md: "Subagent fallback triggered for [task]"

**Do NOT stall the session waiting for a broken subagent.**

## SKIP-AND-CONTINUE
If a TODO item is blocked by something outside your control:
1. Log to .claude/BLOCKED.md: `[date] [item] — [reason]`
2. Move to the next TODO item
3. Circle back to blocked items at session end

## Rules
- Tests are the SPECIFICATION. Never modify tests to make them pass.
- If a test seems wrong, ASK the user. Do not silently change it.
- One behavior per test. Tests are documentation.
- Mock external dependencies, NEVER mock the unit under test.
