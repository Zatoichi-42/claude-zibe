---
name: self-plan
description: >
  Think before building. Self-interview, critique, then emit provable TODO items.
  Use for complex features, at session start, or when triggered by "/plan".
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
  - Glob
  - Grep
  - Agent
---

# Self-Plan — Think Before You Build

## Why This Exists
Building the wrong thing fast is the biggest waste in autonomous coding.
This skill forces a structured pause: understand → challenge → simplify →
emit provable TODO items with machine-checkable acceptance criteria.

## The Protocol

### Round 1: UNDERSTAND
Ask and answer in .claude/PLAN.md:
1. What is the user asking for? (restate concretely)
2. What does "done" look like? (acceptance criteria — TESTABLE)
3. What are the inputs and outputs?
4. What existing code does this touch? (READ the relevant files NOW)

### Round 2: CHALLENGE
Read .claude/OPEN-QUESTIONS.md if it exists. For each question, answer it
about the current plan. Standard challenges:
- What happens if the session dies mid-implementation?
- Does this work with zero existing tests?
- What's the simplest way this could fail?
- Are we adding complexity before proving simple works?

If the task is large (>5 files), delegate critique to self-critic agent:
```
Agent(
  agent_type="self-critic",
  prompt="Read .claude/PLAN.md. Find every flaw. Write to .claude/PLAN-CRITIQUE.md",
)
```

### Round 3: SIMPLIFY
1. What's the SMALLEST change that satisfies acceptance criteria?
2. WITHOUT new dependencies?
3. WITHOUT new abstractions?
4. How many files change? (>5 = break it down)

### Round 4: EMIT PROVABLE TODO ITEMS ← THE KEY IMPROVEMENT
Convert each acceptance criterion into a TODO item with proof metadata.

Format:
```markdown
- [ ] [description]
  proof-command: [shell command that exits 0 if done, non-zero if not]
```

Examples:
```markdown
- [ ] Forward returns computed for 1D, 5D, 10D, 20D windows
  proof-command: python -m pytest tests/test_forward_returns.py -v

- [ ] Hit rate by setup type is populated in signal_quality output
  proof-command: python -c "import json; d=json.load(open('output/latest.json')); assert len(d['signal_quality']['hit_rate_by_setup']) > 0"

- [ ] Score monotonicity measured via Spearman correlation
  proof-command: python -m pytest tests/test_monotonicity.py -k "spearman" -v

- [ ] Sector-relative returns computed where ETF mapping exists
  proof-command: python -m pytest tests/test_sector_relative.py -v
```

**Every TODO item MUST have a proof-command.** If you can't write a
proof-command, the acceptance criterion is too vague — make it concrete.

### Round 5: SEQUENCE
Order the TODO items by dependency:
1. Foundation items first (models, types, data structures)
2. Core logic next (computations, transformations)
3. Integration last (wiring, CLI, output formatting)
4. Tests are written WITH each item, not as a separate phase

Write the sequenced list to TODO.md (or append to existing).

### Round 6: VERIFY
Read PLAN.md one final time:
- [ ] Every criterion has a proof-command
- [ ] Items are ordered by dependency
- [ ] Each item is one-commit-sized
- [ ] No premature abstractions

## Output
- .claude/PLAN.md — the plan
- TODO.md — updated with provable items
- (optional) .claude/PLAN-CRITIQUE.md — critic feedback

## When NOT to Plan
- Simple bug fixes with clear reproduction steps
- Documentation-only changes
- Config changes
- Items already planned and in TODO.md
