---
name: meta-ratchet
description: >
  Analyze what went wrong, propose rule improvements.
  Use at session end: "/retro", "what went wrong", "retrospective".
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Glob
  - Grep
---

# Meta-Ratchet — Learning From Failure

## The Pipeline: Failure → Rule

### Step 1: IDENTIFY
Read JOURNAL.md and recent git history. Check each pattern:
- Untested changes? (edited source without RED)
- Rabbit holes? (chased unrelated failures)
- False fixes? (claimed done without reproduction)
- Subagent stalls? (TDD subagent failed, no fallback used)
- Hook conflicts? (write-guard blocked legitimate operations)
- Context death? (important state lost on compact)
- Scope creep? (built more than asked)

### Step 2: FORMULATE
For each failure, write a candidate rule:
- Specific (not "be careful" but "create .tdd-red-phase before subagent")
- Actionable (can be followed mechanically)
- Testable (can tell if followed or not)
- Short (one sentence)

### Step 3: CHECK
Does this rule already exist in CLAUDE.md or .claude/rules/?
If yes and was violated: propose clearer phrasing or better enforcement (hook).
If genuinely new: proceed.

### Step 4: PROPOSE
Append to .claude/EVOLUTION.md:
```markdown
## [DATE] — Proposed Rule
**Failure**: [what happened]
**Rule**: [the one-sentence rule]
**Enforcement**: [CLAUDE.md advisory / hook deterministic / skill procedure]
**Status**: PROPOSED
```

### Step 5: SCORE SESSION
Append to .claude/EVOLUTION.md:
```markdown
### Session [DATE]
- Items attempted: N
- Items completed: N
- Subagent fallbacks: N
- Blocked items: N
- Human corrections: N
- Score: [GOOD / ACCEPTABLE / POOR]
```

## Key Principle
CLAUDE.md rules are ~80% followed. Hooks are 100%.
If a rule must be followed every time → make it a hook.
If it's guidance for judgment calls → CLAUDE.md is fine.
