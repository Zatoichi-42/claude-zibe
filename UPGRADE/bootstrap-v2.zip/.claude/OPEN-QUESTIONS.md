# Open Questions — Ask Before Every Major Decision

## Lifecycle
- What happens if this session dies mid-implementation?
- If the Stop hook doesn't fire, what state is lost?

## Observability
- Can the human see what happened without running commands?
- Are results in committed files (survives everything) or only in memory?

## Architecture
- Does this work with zero existing tests?
- Could a simpler solution work?
- Are we adding complexity before proving simple works?

## Autonomy
- Does this require human input to proceed?
- Will any hook block this operation unexpectedly?
- Is the .tdd-red-phase marker set/cleared correctly?

## Integration
- Does this change survive a /compact and session restart?
- Is every completed item committed individually?

---
Add questions here when you discover a gap the system should have caught.
The best questions come from pain — things that went wrong.
