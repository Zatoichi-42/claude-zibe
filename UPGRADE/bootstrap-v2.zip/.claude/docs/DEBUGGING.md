# Debugging Guide — Known Issues & Recovery

## Every failure here WILL happen. These are certainties, not edge cases.

### Hook uses exit 1 instead of exit 2
**Symptom**: Hook runs but action proceeds anyway.
**Cause**: In Claude Code, exit 1 is NON-BLOCKING. Only exit 2 blocks.
**Fix**: Use JSON decision format `{"hookSpecificOutput":{"decision":"block",...}}`
with exit 0, OR use exit 2 for hard block. Never exit 1 for blocking.

### Write-guard blocks TDD test-writer subagent
**Symptom**: Subagent tries to write test file, gets blocked by pre-write-guard.
**Cause**: Subagent doesn't inherit CLAUDE_TDD_PHASE env var.
**Fix**: TDD skill creates `.claude/.tdd-red-phase` marker before subagent.
Write-guard checks for this marker file. Skill removes it after.

### Stop hook infinite loop
**Symptom**: Claude loops forever, context exhausts rapidly.
**Cause**: Stop hook outputs text → Claude processes it → triggers another Stop.
**Fix**: Check `stop_hook_active` field in input JSON. Exit immediately if true.

### jq not installed
**Symptom**: All hooks silently fail. No security enforcement.
**Fix**: Every hook checks `command -v jq` first. Session-start warns if missing.

### Subagent returns empty or errors
**Symptom**: Implementation stalls waiting for subagent output.
**Fix**: TDD skill has FALLBACK procedure. After 2 failed attempts, switch to
direct implementation in main context. Log the fallback.

### Context exhaustion (>70%)
**Symptom**: Vague responses, instructions ignored, hallucinations.
**Fix**: Commit everything. Write JOURNAL.md. Start new session.
Prevention: max 5 TODO items per session. Commit after each.

### Proof-commands not on TODO items
**Symptom**: /prove finds nothing to verify. Items can't be machine-checked.
**Fix**: /plan skill now auto-generates proof-command annotations.
Every acceptance criterion gets a testable proof-command.

### Ratchet baseline never initialized
**Symptom**: ratchet-state.json is empty template after bootstrap.
**Fix**: /bootstrap now measures baseline as part of initialization, not deferred.

## Recovery Commands
```bash
# Revert to last commit
git checkout -- .

# Find and restore a specific file
git log --oneline --all -- path/to/file
git checkout <hash> -- path/to/file

# Fix hook permissions
chmod +x .claude/hooks/*.sh

# Reset ratchet state
rm .claude/ratchet-state.json && /bootstrap

# Clear blocked items after addressing them
> .claude/BLOCKED.md
```
