# Bootstrap Prompt — Paste Into Claude Code

```
I'm starting work on: [PROJECT_NAME]

## What it is
[2-3 sentences describing the project]

## Stack
[e.g. "Python 3.11, pytest, ruff, no frameworks"]

## What exists already
[e.g. "Existing repo with Phase 1 & 2 complete. Phase 3 evaluation layer needed."]

## Phase Goal
[The FIRST deliverable, e.g. "Forward return evaluation for surfaced candidates with provable hit-rate metrics"]

---

Before writing code:

1. Read CLAUDE.md at project root.
2. Read TODO.md for current tasks with proof-commands.
3. Run /bootstrap to verify environment and measure baseline.
4. Run /health to confirm current state.
5. Run /plan [Phase Goal] to create a plan with provable acceptance criteria.
6. Then begin implementation with /implement for each TODO item, one at a time.

For every item:
- Write tests FIRST (RED). Implement MINIMUM to pass (GREEN). Refactor. Commit.
- If stuck after 3 attempts: log to .claude/BLOCKED.md, skip to next item.
- Commit after EACH completed item, not in bulk.
- Max 5 items per session. Then /retro and stop.

When done with the batch:
- Run /prove to verify completed items.
- Run /retro to analyze the session.
- Update TODO.md and commit.
- Tell me what you accomplished, what's blocked, and what comes next.

If anything is unclear, ASK before guessing.
If tests fail after a change, FIX the code (not the tests) or REVERT.
```

## Customization

### For Python projects
Add: `ruff check --fix . && ruff format .` as lint/format commands in CLAUDE.md.

### For Node/TypeScript projects  
Change CLAUDE.md stack section. Add `npx prettier --write` to post-edit hook.

### For overnight autonomous runs
Use the conductor script:
```bash
bash .claude/scripts/conductor.sh --auto --budget 5
```
