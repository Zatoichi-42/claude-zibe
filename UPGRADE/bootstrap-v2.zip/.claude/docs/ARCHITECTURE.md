# Architecture & Design Decisions

## System Overview
```
HUMAN (sets direction via program.md and TODO.md)
  ↓
CLAUDE.md (constitution — loaded every session, <25 rules)
  ↓
┌──────────┐ ┌──────────┐ ┌──────────┐
│  HOOKS   │ │  SKILLS  │ │  AGENTS  │
│(enforce) │ │(how-to)  │ │(workers) │
│100% fire │ │on-demand │ │isolated  │
└──────────┘ └──────────┘ └──────────┘
  ↓
THE RATCHET (baseline → hypothesize → implement → measure → keep/revert)
  ↓
GIT (memory, undo, branching)
```

## Key Decisions

### 1. CLAUDE.md is advisory (~80% followed). Hooks are deterministic (100%).
Security-critical rules MUST be hooks. Style preferences can be CLAUDE.md.

### 2. Subagents for context isolation in TDD.
Test-writer and implementer run in separate context windows to prevent
the LLM from writing tests that match its planned implementation.

### 3. Write-guard uses marker files, not env vars.
Env vars don't propagate to subagents. The TDD skill creates/removes
`.claude/.tdd-red-phase` as a filesystem signal to the write-guard hook.

### 4. One commit per TODO item.
Prevents mega-session loss. Each item is atomic and revertable.

### 5. Skip-and-continue over block-and-stall.
When stuck on one item, log it to BLOCKED.md and move on.
A stalled session produces zero value. A skipping session produces partial value.

### 6. Proof-commands on TODO items.
Every TODO item should have a machine-checkable proof-command.
/prove runs them and marks items complete. No ceremony, one command.

### 7. The ratchet never goes backward.
Inspired by Karpathy's AutoResearch. Score can only increase.
Bad changes are automatically reverted. Safe for autonomous operation.

### 8. Three levels of self-correction.
- Meta-ratchet (rule-level): "Claude skipped TDD" → proposes rule
- Self-critic (plan-level): "This plan has a gap" → revises plan
- Ratchet loop (code-level): "This change hurt metrics" → reverts

### 9. Continuous journaling survives everything.
Stop hook writes JOURNAL.md every turn. If session crashes, journal
is at most one turn old. SessionStart reads it on resume.

### 10. Fallback over failure.
If subagent stalls → fall back to direct implementation.
If hook blocks incorrectly → marker file overrides.
If ratchet stalls → skip direction, try another.
The system degrades gracefully, never halts.
