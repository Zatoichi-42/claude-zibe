# Patterns & Anti-Patterns

## Patterns That Work

### The Marker File Pattern
When hooks need to know about state set by skills:
1. Skill creates a marker file: `touch .claude/.tdd-red-phase`
2. Hook checks for marker: `[ -f ".claude/.tdd-red-phase" ]`
3. Skill removes marker when done: `rm -f .claude/.tdd-red-phase`
Why: Env vars don't propagate to subagents. Marker files are filesystem-level.

### The Skip-and-Continue Pattern
When stuck on one item:
1. Log to BLOCKED.md: `[date] [item] — [reason]`
2. Move to next TODO item
3. Return to blocked items at session end
Why: A stalled session produces zero value.

### The Proof-Command Pattern
Every TODO item gets a machine-checkable verification:
```
- [ ] Forward returns computed
  proof-command: python -m pytest tests/test_forward_returns.py -v
```
/prove runs the command, marks the item if it passes.

### The Fallback Pattern
1. Try subagent first (isolated context)
2. If subagent stalls/errors after 2 tries → direct implementation
3. Log the fallback in JOURNAL.md
4. Move on

### The One-Commit-Per-Item Pattern
Commit after each TODO item, not at session end.
Why: Mega-sessions lose all progress on context exhaustion.

## Anti-Patterns to Avoid

### The Ceremony Overload
**Don't**: Require 3 commands to mark one item done (prove → sync → commit)
**Do**: One command (/prove) does all three steps
**Scar**: The old 3-step ceremony was never executed because implementation stalled first.

### The Env Var Assumption
**Don't**: Rely on env vars for inter-process signaling (subagents don't inherit them)
**Do**: Use marker files on the filesystem
**Scar**: CLAUDE_TDD_PHASE was never set; write-guard blocked test-writing subagent.

### The Mega-Session
**Don't**: Work for hours in one session until context exhausts
**Do**: Max 5 TODO items per session. Commit after each.
**Scar**: 215-message session at 64% context with autocompact errors.

### The Inert Scaffold
**Don't**: Create 40 files of scaffolding that never gets exercised
**Do**: Bootstrap should initialize AND measure baseline in one step
**Scar**: ratchet-state, proof-log, and EVOLUTION.md were all empty after a full session.

### The Silent Subagent Failure
**Don't**: Let subagent failures silently stall the parent session
**Do**: Timeout + fallback + logging
**Scar**: TDD subagent was blocked by write-guard; session stalled for 45 minutes.
