# Quick Reference

## Commands
| Command | What | Speed |
|---------|------|-------|
| /bootstrap | Init env + measure baseline | once |
| /plan [feat] | Self-interview → provable TODO items | before building |
| /implement [feat] | TDD with fallback (RED→GREEN→REFACTOR) | per item |
| /prove | Run proof-commands, mark TODO complete | after implementing |
| /ratchet | Autonomous improvement loop | when ready |
| /health | Full project health check | anytime |
| /check | 30-second spot check (stdout only) | anytime |
| /retro | Session retrospective → rule proposals | end of session |
| /digest | Daily text summary report | end of day |

## TDD Cycle
```
1. touch .claude/.tdd-red-phase     ← tell write-guard we're writing tests
2. Write failing test (subagent or direct)
3. rm .claude/.tdd-red-phase        ← back to implementation mode
4. Implement minimum to pass
5. Refactor while green
6. git commit
```

## When Stuck
```
1. Try 3 times
2. Log to .claude/BLOCKED.md: [date] [item] — [reason]
3. Skip to next TODO item
4. Come back at session end
```

## Context Budget
| Usage | Action |
|-------|--------|
| 0-50% | Work freely |
| 50% | Commit, write JOURNAL.md |
| 70% | Stop session, start fresh |

## Session Discipline
- Max 5 TODO items per session
- Commit after EACH item
- /retro at session end (even good sessions)

## Key Files
```
CLAUDE.md                    → Constitution (<25 rules)
TODO.md                      → Tasks with proof-commands
program.md                   → Ratchet experiment directions
.claude/settings.json        → Hooks and permissions
.claude/JOURNAL.md           → Live state (updated every turn)
.claude/BLOCKED.md           → Stuck items
.claude/EVOLUTION.md         → Rule improvement proposals
.claude/ratchet-state.json   → Experiment history
.claude/.tdd-red-phase       → Marker: test-writing in progress
.claude/hooks/*.sh           → Deterministic enforcement
.claude/skills/*/SKILL.md    → On-demand workflows
.claude/agents/*.md          → Isolated subagents
.claude/docs/                → Architecture, patterns, debugging
```

## Proof-Command Format (in TODO.md)
```markdown
- [ ] Description of what's done
  proof-command: shell command that exits 0 if done
```

## Emergency Recovery
```bash
git checkout -- .                    # Revert everything
git log --oneline -10                # Find good commit
git reset --hard <hash>              # Nuclear option
chmod +x .claude/hooks/*.sh          # Fix permissions
rm .claude/ratchet-state.json        # Reset ratchet
> .claude/BLOCKED.md                 # Clear blocked items
```

## Autonomous Overnight
```bash
bash .claude/scripts/conductor.sh --auto --budget 5
bash .claude/scripts/conductor.sh --check
```
