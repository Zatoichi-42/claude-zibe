# CLAUDE.md — Project Constitution

## Prime Directives (6 rules — each prevents a named failure)
1. Read this file, then .claude/rules/, then relevant skills before work.
2. Do not edit non-test source without a failing test (RED signal).
   _Scar: Claude wrote code that "worked" but solved the wrong problem._
3. No silent failures — every code path returns data or a typed error.
   _Scar: Empty catch blocks hid bugs that compounded for 3 sessions._
4. Do not chase unrelated failing tests. Note them, stay on task.
   _Scar: Claude abandoned the current feature to fix a pre-existing test failure._
5. One TODO item per commit. Commit after each GREEN, not at session end.
   _Scar: Mega-session lost all progress when context exhausted at 90%._
6. When stuck for >3 attempts on one item, skip it, log why, move to next.
   _Scar: Subagent stalled on hook conflict; entire session blocked for 45 minutes._

## Stack
- Python 3.11+, pytest, ruff
- Test runner: `python -m pytest`
- Linter: `ruff check`
- Formatter: `ruff format`

## Critical Commands
```bash
# Test (single file — prefer this)
python -m pytest <file> -v

# Test (full suite)
python -m pytest --tb=short -q

# Lint + format
ruff check --fix . && ruff format .

# Type check (if mypy/pyright configured)
# python -m mypy src/
```

## TDD Protocol
1. Name the test first — what behavior are you proving?
2. Write the test. Run it. It MUST fail (RED).
3. Implement the MINIMUM to pass (GREEN). No extras.
4. Refactor only while GREEN. Run tests after each refactor step.
5. If user gives an exact error string, reproduce it in a test.
6. NEVER modify tests to make them pass — fix the source.

## Completion Protocol
When an item is done: `run tests → commit → update TODO.md`
That's it. No multi-command ceremony. If tests pass and code is committed, it's done.

## Context Management
- At 50%: commit everything, write status to .claude/JOURNAL.md
- At 70%: commit, stop, new session
- After compact: read .claude/JOURNAL.md for state recovery

## Git
- Branch: `feat/`, `fix/`, `refactor/`, `test/`
- Commits: conventional (`feat:`, `fix:`, `test:`, `refactor:`)
- NEVER commit to `main` directly
- Commit after EACH completed TODO item, not in bulk

## Session Discipline
- Max 5 TODO items per session. Then commit, report, stop.
- If a TODO item is blocked, log the reason in JOURNAL.md, skip to next.
- At session end: update TODO.md, write JOURNAL.md, commit.

## References
- @.claude/docs/ARCHITECTURE.md
- @.claude/docs/PATTERNS.md
- @.claude/docs/DEBUGGING.md
- .claude/skills/ — load on demand
- .claude/agents/ — isolated subagents
