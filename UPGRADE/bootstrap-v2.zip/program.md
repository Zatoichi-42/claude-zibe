# Program: Research & Improvement Directions

## How To Use
1. Write directions as numbered items with ONE clear hypothesis each
2. Include how to measure success
3. Agent explores top-to-bottom, skipping exhausted directions
4. Mark completed with ✅, failed with ❌, skipped with ⏭️

## Current Directions

### Code Quality
1. [ ] Add missing type annotations — eliminate `any` types
   - Measure: `grep -r ": any\|: Any" src/ | wc -l`
   - Better = count closer to 0

2. [ ] Extract duplicated logic into shared utilities
   - Measure: duplicate line count (manual review)
   - Better = fewer duplicates

3. [ ] Improve error handling — find empty catch/except blocks
   - Measure: `grep -rn "except:$\|catch.*{}" src/ | wc -l`
   - Better = fewer silent catches

### Test Coverage
4. [ ] Add tests for uncovered functions
   - Measure: test count before/after
   - Better = more tests passing

5. [ ] Add edge case tests for core logic
   - Measure: test count + mutation testing if available
   - Better = more tests, higher mutation score

### Performance
6. [ ] Identify and remove unused imports
   - Measure: linter warning count
   - Better = fewer warnings

## Exhausted Directions
<!-- Agent moves directions here after 3+ failed attempts -->

## Completed Improvements
<!-- Agent moves successful directions here with results -->
