# TODO: Phase 3 Evaluation and Calibration

## Foundation (do first — other items depend on these)

- [ ] Define forward-return evaluation windows: 1D, 5D, 10D, 20D
  proof-command: python -m pytest tests/test_models.py -k "forward_window" -v

- [ ] Build evaluation_targets section in output packets
  proof-command: python -c "import json; d=json.load(open('output/latest.json')); assert 'evaluation_targets' in d, 'missing evaluation_targets'"

- [ ] Build forward_outcomes section in output packets
  proof-command: python -c "import json; d=json.load(open('output/latest.json')); assert 'forward_outcomes' in d, 'missing forward_outcomes'"

## Core Computations

- [ ] Build outcome tracker for every surfaced candidate
  proof-command: python -m pytest tests/test_outcome_tracker.py -v

- [ ] Link candidate outcomes to run metadata, setup type, and scores
  proof-command: python -m pytest tests/test_evaluator.py -k "link_metadata" -v

- [ ] Compute forward returns for surfaced candidates
  proof-command: python -m pytest tests/test_forward_returns.py -v

- [ ] Compute benchmark-relative forward returns versus SPY
  proof-command: python -m pytest tests/test_forward_returns.py -k "benchmark" -v

- [ ] Compute sector-relative forward returns where sector ETF mapping exists
  proof-command: python -m pytest tests/test_forward_returns.py -k "sector_relative" -v

## Signal Quality Metrics

- [ ] Measure hit rate for top-N candidates per run
  proof-command: python -m pytest tests/test_hit_rate.py -k "top_n" -v

- [ ] Measure hit rate by setup type
  proof-command: python -m pytest tests/test_hit_rate.py -k "by_setup" -v

- [ ] Measure hit rate by score bucket or decile
  proof-command: python -m pytest tests/test_hit_rate.py -k "by_bucket" -v

- [ ] Measure average forward return by score bucket
  proof-command: python -m pytest tests/test_hit_rate.py -k "avg_return_by_bucket" -v

- [ ] Measure candidate performance versus universe median
  proof-command: python -m pytest tests/test_evaluator.py -k "universe_median" -v

- [ ] Measure early-discovery hit rate separately
  proof-command: python -m pytest tests/test_evaluator.py -k "early_discovery" -v

- [ ] Measure false-positive rate for early-discovery names
  proof-command: python -m pytest tests/test_evaluator.py -k "false_positive" -v

- [ ] Measure empty-run frequency
  proof-command: python -m pytest tests/test_evaluator.py -k "empty_run" -v

- [ ] Measure filter fallout by stage
  proof-command: python -m pytest tests/test_evaluator.py -k "filter_fallout" -v

- [ ] Measure score monotonicity via Spearman correlation
  proof-command: python -m pytest tests/test_monotonicity.py -v

## Calibration

- [ ] Build calibration summaries for thresholds and score weights
  proof-command: python -m pytest tests/test_calibration.py -v

- [ ] Add signal_quality section to output packets (fully populated)
  proof-command: python -c "import json; d=json.load(open('output/latest.json')); sq=d['signal_quality']; assert len(sq.get('hit_rate_by_setup',{})) > 0, 'hit_rate_by_setup empty'"

- [ ] Add calibration_summary section to output packets (fully populated)
  proof-command: python -c "import json; d=json.load(open('output/latest.json')); cs=d['calibration_summary']; assert len(cs.get('component_weights',{})) > 0, 'calibration empty'"

## Evaluability & Robustness

- [ ] Add evaluability checks for sufficient outcome data
  proof-command: python -m pytest tests/test_evaluator.py -k "evaluability" -v

- [ ] Ensure all missing forward data is surfaced explicitly
  proof-command: python -m pytest tests/test_evaluator.py -k "missing_data" -v

- [ ] Update canonical latest.json with evaluated content
  proof-command: python -c "import json, os; assert os.path.exists('output/latest.json'), 'no latest.json'; d=json.load(open('output/latest.json')); assert 'forward_outcomes' in d and 'signal_quality' in d"

## Test Coverage

- [ ] Tests for forward-return calculations
  proof-command: python -m pytest tests/test_forward_returns.py -v

- [ ] Tests for benchmark-relative and sector-relative outcomes
  proof-command: python -m pytest tests/test_forward_returns.py -k "benchmark or sector" -v

- [ ] Tests for evaluation joins
  proof-command: python -m pytest tests/test_evaluator.py -k "join" -v

- [ ] Tests for hit-rate summaries
  proof-command: python -m pytest tests/test_hit_rate.py -v

- [ ] Tests for monotonicity checks
  proof-command: python -m pytest tests/test_monotonicity.py -v

- [ ] Tests for calibration summaries
  proof-command: python -m pytest tests/test_calibration.py -v

- [ ] Validate Phase 3 outputs stable and machine-readable
  proof-command: python -m pytest tests/test_packet_schema.py -v

## Completed
<!-- /prove moves completed items here -->
